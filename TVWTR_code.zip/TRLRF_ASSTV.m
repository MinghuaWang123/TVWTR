
function [X,G_out,G_init,Convergence_rec]=TRLRF_ASSTV(data,W,r,maxiter,alpha,K,ro,Lamda,tau,tol)
T=data.*W;
N=ndims(T);
S=size(T);
X=rand(S);
% G=TR_initcoreten(S,r);
G=TR_initcoreten_LR(S,r);
G_init=G;
M=cell(N,3); 
Y=cell(N,3);

sizeD=S;
pn               = prod(sizeD);
h               = sizeD(1);
w               = sizeD(2);
d               = sizeD(3);
%% 
Eny_x   = ( abs(psf2otf([+1; -1], [h,w,d])) ).^2  ;
Eny_y   = ( abs(psf2otf([+1, -1], [h,w,d])) ).^2  ;
Eny_z   = ( abs(psf2otf([+1, -1], [w,d,h])) ).^2  ;
Eny_z   =  permute(Eny_z, [3, 1 2]);
determ  =  Eny_x + Eny_y + Eny_z;
F               = zeros(3*pn,1);     % F : auxiliary variable for tv
Gamma           = F;                % The multiplier for DZ-F
M2              = zeros(S);


for i=1:N
    G{i}=1*G{i};
    for j=1:3
        M{i,j}=zeros(size(G{i}));
        Y{i,j}=sign(G{i});
    end
end
K_max=10;
Convergence_rec=zeros(1,maxiter);
iter=0;
while iter<maxiter
    iter=iter+1;
        % update G
    for n=1:N
        Msum=Msum_fun(M);
        Ysum=Msum_fun(Y);
        Q=tenmat_sb(Z_neq(G,n),2);  Q=Q'; % Q is the right part of the right part of the relation equation
        G{n}=Gfold((Lamda*tenmat_sb(X,n)*Q'...
            +K(1)*Gunfold(Msum{n},2)+Gunfold(Ysum{n},2))*pinv((Lamda*(Q*Q')...
            +3*K(1)*eye(size(Q,1),size(Q,1)))),size(G{n}),2);
        % update M
        for j=1:3
           Df=Gunfold(G{n}-Y{n,j}/K(1),j);
           M{n,j}=Gfold(Pro2TraceNorm(Df,alpha(j)/K(1)),size(G{n}),j);
        end
        
    end
    
    %% - update Z
    diffT_p  = diffT3( K(2)*F - Gamma, sizeD );
    numer1   = reshape( diffT_p + K(3)*X(:) + M2(:), sizeD);
    z        = real( ifftn( fftn(numer1) ./ (K(2)*determ + K(3)) ) );
    Z        = reshape(z,sizeD);

    %% - update F
    diff_Z     = diff3(Z(:), sizeD); 
    F          = softthre( diff_Z+ Gamma/K(3), tau/K(3) );  

    % update X
    lastX=X;
    X_hat=real( ifftn( fftn(Lamda*coreten2tr(G)+K(2)*Z-M2)./(Lamda+K(2))) );
    X=X_hat;
    X(W==1)=T(W==1);
    
    % update Y
    for n=1:N
        for j=1:3
        Y{n,j}=Y{n,j}+K(1)*(M{n,j}-G{n});
        end
    end
       %% update Gamma
       
       M2         = M2 + K(2)*(X-Z); 
    Gamma      =  Gamma+K(3)*(diff_Z-F);   
    

     K=min(K*ro,K_max);
    % evaluation
    G_out=G;
    err_x=abs((norm(lastX(:))-norm(X(:)))/norm(X(:)));
    psnr = PSNR3D(data * 255, X * 255);
    if (err_x<tol)
        fprintf('iteration stop at %.0f\n',iter); break
    end
    if (mod(iter,100)==0||iter==1)
        Ssum_G=0; % singular value
        for j=1:N
            [~,vz1,~]=svd(double(mytenmat(G{j},1,1)),0);
            [~,vz2,~]=svd(double(mytenmat(G{j},2,1)),0);
            [~,vz3,~]=svd(double(mytenmat(G{j},3,1)),0);
            Ssum_G=Ssum_G+sum(vz1(:))+sum(vz2(:))+sum(vz3(:));
        end
        f_left=Ssum_G;
        f_right=Lamda*(norm(X(:)-X_hat(:)))^2;
        Convergence_rec(iter)=f_left+f_right;
        fprintf('TRLRF: Iter %.0f, Diff %.2d, Reg %.2d, Fitting %.2d\n',iter,err_x,f_left,f_right);
    end
end
end