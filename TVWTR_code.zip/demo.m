%% demo_SLC

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Author: Minghua Wang (minghuawang1993@163.com)
% Last version: Oct. 11, 2020
% Article: Total Variation Regularized Weighted Tensor Ring Decomposition for Missing Data Recovery in High-dimensional Optical Remote Sensing Images
% https://ieeexplore.ieee.org/document/9399661
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


currentFolder = pwd;
addpath(genpath(currentFolder));


close all;clear all;clc
load Sentinel-2.mat; 

r=[15,15,10];
maxiter=120; % maxiter 300~500
tol=1e-8; % 1e-6~e-8   
b=[10];

Lambda=[ 0.8 ];  
ro=1; % 1~1.5
tau=[0.0005];
k1=[ 0.01 ];
K=[0.01 k1  k1]; 
alpha = [1,b,1];
alpha = alpha / sum(alpha);


tic;
[X_hat,G,G_init]=TRLRF_ASSTV(C,W,r,maxiter,alpha,K,ro,Lambda,tau,tol);
toc;
TRLRF_result1=calcDenoiseResult( C,T,X_hat,' TVWTR',false );

 [h,v,z]=size(C);
 A=reshape(C,h*v,z);
msaLnewSSTV=MSA(C,X_hat);
ergasLnewSSTV = ErrRelGlobAdimSyn(C,X_hat);

B=reshape(X_hat,h*v,z);
msadX= mSAD(A,B);

